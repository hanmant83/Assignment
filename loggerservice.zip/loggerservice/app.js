require('dotenv').config();
const express = require("express");
const cors = require('cors');
const swaggerUI = require('swagger-ui-express'); 
const app = express();
const logRouter = require("./src/routes/log.routes");
const docs = require('./src/docs');
//create connection to database
const db = require('./src/configs/db.config');
//db.connectToDB();

//Allow all cors
app.use(cors());
app.use(express.json());

app.use("/", logRouter);

// Global error handling
app.use((err, _req, res, next) => {
    res.status(500).send("Uh oh! An unexpected error occured.")
});

//Swagger Configuration     
app.use('/api-docs',swaggerUI.serve,swaggerUI.setup(docs)); 
/** 
 * @swagger 
 * /Employees: 
 *   get: 
 *     description: Get all Employee 
 *     responses:  
 *       200: 
 *         description: Success  
 *   
 */  
app.get('/Employees',(req,res)=>{  
    res.send([  
        {  
            id:1, Name:'Jk'  
        },  
        {  
            id:2,Name:'Jay'  
        }  
    ])  
}); 

const PORT = process.env.PORT || 5001;
app.listen(PORT, function () {
    console.log(`Server is running on port: ${PORT}`);
});