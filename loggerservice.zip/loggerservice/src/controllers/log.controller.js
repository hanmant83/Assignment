const logService = require('../services')
const utils = require('../utils');
async function create(req, res, next) {
  try {
    const resp = await logService.create(req);
    res.json(await programmingLanguages.create(req.body));
    res.send(resp)
  } catch (err) {
    res.status(500).send({
      message:
        err.message || "Something went wrong"
    });
  }
}

async function get(req, res, next) {
  try {
    const resp = await logService.get(req);
    //res.json(await programmingLanguages.create(req.body));
    res.send(resp)
  } catch (err) {
    res.status(500).send({
      message:
        err.message || "Something went wrong"
    });
  }
}

module.exports = {
    create,
    get
  };
