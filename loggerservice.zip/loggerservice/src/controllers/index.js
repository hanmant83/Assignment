const logController = require('./log.controller');

module.exports = {
    logController
}