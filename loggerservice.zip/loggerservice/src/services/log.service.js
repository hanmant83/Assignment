const db = require("../models");
const logs = db.logs;
const utils = require('../utils');

async function create(req){
     // Create a Log
     const log = new Log({
        Source: req.body.source,
        Module: req.body.module,
        Category: req.body.category,
        StatusCode: req.body.statuscode,
        Message: req.body.message,
      });
      let result = {};
      // Save Tutorial in the database
      logs
        .save(log)
        .then(data => {
            result.data = data;
            result.status = 200;
            result.message = "Log added succesfully";
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while creating the Log."
          });
        });
  
    return {message};
}

async function get(req){
  console.log(req.body)
  const query = await utils.transformGetQuery(req.body);
  logs
    .find(query) 
    .then(data =>{

    })
}

  module.exports = {
    create,
    get
  }