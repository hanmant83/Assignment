const logService = require('./log.service');

module.exports = {
    ...logService
}