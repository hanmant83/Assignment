const express = require("express");
const router = express.Router();
const logController = require('../controllers');
const Validator = require('../middlewares/Validator')

//Create log
router.post('/logs/create', Validator('logs') ,logController.create);

//Get logs from database
router.post('/logs/list', logController.get);

module.exports = router;