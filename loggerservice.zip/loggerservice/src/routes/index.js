const logRoutes = require('./log.routes');

module.exports = {
    ...logRoutes
}