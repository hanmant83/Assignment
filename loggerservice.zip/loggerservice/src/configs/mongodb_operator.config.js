const operators = {
    "eq": "$eq",
    "lt": "$lt",
    "gt": "$gt",
    "lte": "$lte",
    "gte": "$gte",
    "and": "$and",
    "or": "$or",
    "in": "$in",
    "ne": "$ne",
    "nin": "$nin",
    "like":"\\"
}
module.exports = {
    operators
}
