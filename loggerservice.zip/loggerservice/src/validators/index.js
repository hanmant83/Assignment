const logs = require('./logrequest.validator')

module.exports = {
    logs
}