const Joi = require('joi');

const registerSchema = Joi.object({
    source: Joi.string().required(),
    module: Joi.string().required(),
    name: Joi.string(),
    category: Joi.string().required(),
    statuscode: Joi.number().required(),
    data: Joi.object(),
    request: Joi.string(),
    response: Joi.string(),
    requestId: Joi.string(),
    message: Joi.string()
});
module.exports = {
    registerSchema
}