module.exports = {
    servers:[
        {
            url:"http://localhost:5001",
            description:"Local server"
        },
    ]
}