const getLogs = require('./get-logs');
const createLogs = require('./create-log');

module.exports = {
    paths:{
        '/logs/list':{
            ...getLogs
        },
        '/logs/create':{
            ...createLogs
        }
    }
}