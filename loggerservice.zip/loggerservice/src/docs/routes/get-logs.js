module.exports = {
    post:{
        tags:['Logs'],
        description: "Get logs",
        operationId: "getLogs",
        parameters:[],
        requestBody: {
            content:{
                'application/json': {
                    schema:{
                        $ref:'#/components/schemas/Queries'
                    }
                }
            }
        },
        responses:{
            '201':{
                description: "Logs return successfully",
                content:{
                    'application/json': {
                        schema:{
                            $ref:'#/components/schemas/Queries'
                        }
                    }
                }
            },
            '500':{
                description: 'Server error'
            }
        }
    }
}