module.exports = {
    post:{
        tags:['Logs'],
        description: "Create logs",
        operationId: "createLog",
        parameters:[],
        requestBody: {
            content:{
                'application/json': {
                    schema:{
                        $ref:'#/components/schemas/Log'
                    }
                }
            }
        },
        responses:{
            '201':{
                description: "Log created successfully"
            },
            '500':{
                description: 'Server error'
            }
        }
    }
}