module.exports = {
    tags:{
        name:'Logs'
    }
}