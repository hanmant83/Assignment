module.exports = {
    components: {
        schemas: {
            Log: {
                type: "object",
                properties: {
                    source: {
                        type: 'string',
                        description: "Request come from which source",
                        enum: ['WEB', 'API', "UTILITIES"],
                        example: "WEB"
                    },
                    module: {
                        type: 'string',
                        description: "Logs from which module",
                        enum: ['ACCRD'],
                        example: "ACCRD"
                    },
                    name: {
                        type: 'string',
                        description: "Name",
                        example: "StudentApprove"
                    },
                    category: {
                        type: 'string',
                        description: "category of log",
                        enum: ['SUCCESS', 'INFO', 'ERROR', 'AUDIT'],
                        example: "SUCCESS"
                    },
                    statuscode: {
                        type: 'number',
                        description: "status code of request",
                        example: "200"
                    },
                    data: {
                        type: 'object',
                        properties: {
                            screen: {
                                type: 'string',
                                description: "scrren where event clicked",
                                example: ""
                            },
                            event: {
                                type: 'string',
                                description: "clicked event",
                                example: "Approve school"
                            },
                            url: {
                                type: "string",
                                description: "uRL",
                                example: "http://localhost/"
                            }
                        }
                    },
                    request: {
                        type: 'object',
                        description: "request object",
                        example: ""
                    },
                    response: {
                        type: 'object',
                        description: "response object",
                        example: ""
                    },
                    requestId: {
                        type: 'string',
                        description: "Unique id",
                        example: ""
                    }
                }
            },
            Query: {
                type: "object",
                properties: {
                    key: {
                        type: 'string',
                        description: "column name",
                        enum: ['source', 'module', 'name', 'category', 'requestId', 'statuscode', 'message'],
                        example: "source"
                    },
                    value: {
                        type: 'string',
                        description: "value",
                        example: "WEB"
                    },
                    operations: {
                        type: 'string',
                        description: "operations to performe above query",
                        enum: ["eq", "lt", "gt", "lte", "gte", "ne", "in", "nin"],
                        example: "eq"
                    },
                }
            },
            Queries: {
                type: "array",
                items: {
                    $ref: '#/components/schemas/Query'
                }
            }
        }
    }
}
