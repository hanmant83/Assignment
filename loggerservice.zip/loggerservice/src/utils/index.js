const operators = require('../configs/mongodb_operator.config');
const messages = require('./responseFormat');
async function transformGetQuery(data) {
   if(data.length) {
     if(data.length == 1) {
       return {} 
     } else {
       const query = data.reduce((a, c) => {
       const obj = {};
       const operator = operators.operators[c.operator] || '$eq';
       obj[c.key] = {[operator]: c.value};
       a.push(obj);
       return a;
       },[])
       return query;
     }
   } else {
    return 
   }
}

module.exports = {
    transformGetQuery,
    messages
  }