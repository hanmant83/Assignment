const Responses = {
    RES_RECORD_FETCHED: {
        message: 'Record(s) fetched successfully',
        code: 200,
        success: true
    },
    RES_RECORD_CREATED: {
        message: 'Record created successfully',
        code: 200,
        success: true
    },
    RES_DATA_NOT_FOUND: {
        message: 'Data not found',
        code: 401,
        success: true
    },
    RES_SOMETHING_WRONG: {
        message: 'Something went wrong',
        code: 500,
        success: true
    }
}