module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        Source: { type: String, required: true },
        Module: { type: String, required: true },
        Name: String,
        Category: { type: String, required: true },
        StatusCode: { type: Number, required: true },
        Data: {
          Screen: String,
          Event: String,
          URL: String
        },
        Request: String,
        Response: String,
        RequestId: String,
        Message: { type: String, required: true }
      },
      { timestamps: true }
    );
  
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
  
    const Logs = mongoose.model("logs", schema);
    return Logs;
  };